/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   bigdirtytester.c                                   :+:    :+:            */
/*                                                     +:+                    */
/*   By: rcorke <marvin@codam.nl>                     +#+                     */
/*                                                   +#+                      */
/*   Created: 2019/01/11 12:09:40 by rcorke        #+#    #+#                 */
/*   Updated: 2019/01/19 17:52:51 by rcorke        ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <ctype.h>
#include "libft.h"


void	red()
{
	printf("\033[0;31m");
}

void	green()
{
	printf("\033[0;32m");
}

void	yellow()
{
	printf("\033[0;33m");
}

void	blue()
{
	printf("\033[0;34m");
}

void	reset()
{
	printf("\033[0m");
}

static void	striteritest(unsigned int x, char *s)
{
	while (s[x] != '\0')
		s[x++] = 'x';
}

static char	strmaptest(char s)
{
	if (s > '5')
		return ('h');
	return ('r');
}

static char	strmapitest(unsigned int n, char s)
{
	(void)n;
	if (s > '5')
		return ('h');
	return ('r');
}

char *randomstring(int length)
{
	char *str;
	int x;

	if (length < 1)
	{
		printf("Invalid random string length, must be positive int");
		return (0);
	}
	str = (char *) malloc (sizeof(char) * length + 1);
	x = 0;
	while (x < length)
	{
		str[x] = rand() % (126 - 33 + 1) + 33;
		x++;
	}
	str[x] = '\0';
	return (str);
}

int	cmp_strcmp(const char *s1, const char *s2)
{
	if (ft_strcmp(s1, s2) != strcmp(s1, s2))
		return (1);
	return (0);
}

int	main(int argc, char **argv)
{

	int result;
	result = 0;

//generate seed for random string
	time_t t;
	srand((unsigned int) time(&t));
//------

//make test string
	char *teststring;
	char *teststring2;
	int len;
	len = 25;
	teststring = randomstring(len);
	teststring2 = randomstring(len);
	char emptystring[strlen(teststring)];
//---

//test emptystring for strcat
	char strcatstring[100] = "Hello";
	char strcatstring2[100] = "Hello";
//--------

//test emptystring for memset
	char	strmemset[100] = "Goodbye";
	char	strmemset2[100] = "Goodbye";

	char	*memsetresult = memset(strmemset2+2, '.', 10*sizeof(char));
	if (strcmp(ft_memset(strmemset+2, '.', 10*sizeof(char)),  memsetresult) != 0)
	{
		printf("memset failed\n");
		result++;
	}

	char	bzero1[11] = "Hellomatey";
	char	ft_bzero1[11] = "Hellomatey";
	bzero(bzero1+1, 4);
	ft_bzero(ft_bzero1+1, 4);
	if (strcmp(bzero1, ft_bzero1) != 0)
	{
		printf("bzero failed\n");
		result++;
	}

	char	memcpy1[25] = "Whatsupchuck";
	char	memcpy2[25] = "Whatsupchuck";
	memcpy(memcpy1, "Alrightmate", 7);
	ft_memcpy(memcpy2, "Alrightmate", 7);
	if (strcmp(memcpy1, memcpy2) != 0)
	{
		printf("memcpy failed\n");
		result++;
	}

	memccpy(memcpy1, "ShakeYoBooty", 'k', 5);
	ft_memccpy(memcpy2, "ShakeYoBooty", 'k', 5);
	if (strcmp(memcpy1, memcpy2) != 0)
	{
		printf("memccpy failed\n");
		result++;
	}

	memmove(memcpy1, "MaryMaryQuiteContrary", 25);
	ft_memmove(memcpy2, "MaryMaryQuiteContrary", 25);
	if (strcmp(memcpy1, memcpy2) != 0)
	{
		printf("memmove failed\n");
		result++;
	}
	if (strcmp(memchr(memcpy1, 'a', 20), ft_memchr(memcpy2, 'a', 20)) != 0)
	{
		printf("memchr failed\n");
		result++;
	}
	if (memcmp(memcpy1, memcpy2, 15) != ft_memcmp(memcpy1, memcpy2, 15))
	{
		printf("memcmp failed\n");
		result++;
	}

	if (cmp_strcmp(randomstring(25), randomstring(25)) != 0)
	{
		printf("strcmp failed\n");
		result++;
	}

	if (strcmp(ft_strdup(teststring), strdup(teststring)) != 0)
	{
		printf("strdup failed\n");
		result++;
	}

	char teststring5[25] = "Whatsupdaddy-45";
	char teststring6[25] = "Whatsupdaddy-4545";

	if (ft_strncmp(teststring5, teststring6, 25) !=  strncmp(teststring5, teststring6, 25))
	{
		printf("strncmp failed\n");
		result++;
	}

	if (strcmp(ft_strcat(strcatstring, teststring), strcat(strcatstring2, teststring)) != 0)
	{
		printf("strcat failed\n");
		result++;
	}

	if (strcmp(ft_strncat(strcatstring, teststring, 10), strncat(strcatstring2, teststring, 10)) != 0)
	{
		printf("strncat failed\n");
		result++;
	}

	teststring = randomstring(len);
	if (ft_strlcat(strcatstring, teststring, strlen(strcatstring)) != strlcat(strcatstring2, teststring, strlen(strcatstring2)))
	{
		printf("strlcat failed\n");
		result++;
	}

	char *strchrcheck = strchr(strcatstring2, '~');
	char *ft_strchrcheck = ft_strchr(strcatstring, '~');
	if (ft_strchrcheck != NULL && strchrcheck != NULL)
	{
		if (strcmp(ft_strchrcheck, strchrcheck) != 0)
		{
			printf("strchr failed\n");
			result++;
		}
	}
	char *strrchrcheck = strrchr(strcatstring2, '~');
	char *ft_strrchrcheck = ft_strrchr(strcatstring, '~');
	if (ft_strrchrcheck != NULL && strrchrcheck != NULL)
	{
		if (strcmp(ft_strrchrcheck, strrchrcheck) != 0)
		{
			printf("strrchr failed\n");
			result++;
		}
	}

	if (strcmp(ft_strcpy(teststring, emptystring), strcpy(teststring, emptystring)) != 0)
	{
		printf("strcpy failed\n");
		result++;
	}
	if (strcmp(ft_strncpy(teststring, emptystring, len), strncpy(teststring, emptystring, len)) != 0)
	{
		printf("strncpy failed\n");
		result++;
	}

	char	*strnstring = "aabbbabaaabbb";
	char	*strnstring2 = "aabbbabaaabbb";
	if (strcmp(ft_strstr(strnstring, "aa"), strstr(strnstring2, "aa")) != 0)
	{
		printf("strstr failed\n");
		result++;
	}
	if (strcmp(ft_strnstr(strnstring, "aabb", 5), strnstr(strnstring2, "aabb", 5)) != 0)
	{
		printf("strstr failed\n");
		result++;
	}

	char atoistr[150] = "\f\f\f\f\f\v\r\t\n        			-74/f---------83647";
	if (ft_atoi(atoistr) != atoi(atoistr))
	{
		printf("atoi failed\n");
		result++;
	}

	if (isalpha('Z') != ft_isalpha('Z'))
	{
		printf("isalpha failed\n");
		result++;
	}
	if (isdigit('0') != ft_isdigit('0'))
	{
		printf("isdigit failed\n");
		result++;
	}
	if (isalnum(':') != ft_isalnum(':'))
	{
		printf("isalnum failed\n");
		result++;
	}
	if (isascii(127) != ft_isascii(127))
	{
		printf("isascii failed\n");
		result++;
	}
	if (isprint(32) != ft_isprint(32))
	{
		printf("isprint failed\n");
		result++;
	}
	if (toupper('f') != ft_toupper('f'))
	{
		printf("toupper failed\n");
		result++;
	}
	if (tolower('f') != ft_tolower('f'))
	{
		printf("tolower failed\n");
		result++;
	}

	if (ft_memalloc(250) == NULL)
	{
		printf("memalloc failed\n");
		result++;
	}

	char *memloc2;
	char **memloc;
	memloc2 = strdup("HelloMate");
	memloc = &memloc2;
	ft_memdel((void**)memloc);
	if (memloc2 != NULL)
	{
		printf("memdel failed\n");
		result++;
	}
	if (ft_strnew(15) == NULL)
	{
		printf("strnew failed\n");
		result++;
	}
	char *delstring;
	char *delstring2;
	delstring = (char *)malloc(sizeof(char) * 25 + 1);
	delstring2 = (char *)malloc(sizeof(char) * 25 + 1);

	strcpy(delstring, "12345678901234567890");
	strcpy(delstring2, "12345678901234567890");
	ft_strdel(&delstring);
	if (delstring != NULL)
	{
		printf("strdel failed\n");
		result++;
	}
	strcpy(teststring, "1234567890");
	strcpy(teststring2, "1234567890");
	ft_strclr(teststring);
	if (strcmp(teststring, teststring2) == 0)
	{
		printf("strclr failed\n");
		result++;
	}

	strcpy(teststring, "1234567890");
	strcpy(teststring2, "1234567890");
	ft_striter(teststring, &ft_strclr);
	if (strcmp(teststring, teststring2) == 0)
	{
		printf("striter failed\n");
		result++;
	}

	strcpy(teststring, "1234567890");
	strcpy(teststring2, "1234567890");
	ft_striteri(teststring, &striteritest);
	if (strcmp(teststring, teststring2) == 0)
	{
		printf("striteri failed\n");
		result++;
	}

	teststring = randomstring(25);
	char *teststring3;
	char *teststring4;
	teststring4 = randomstring(len);
	teststring3 = teststring;
	if (ft_strequ(teststring, teststring3) != 1)
	{
		printf("strequ failed\n");
		result++;
	}
	if (ft_strnequ(teststring, teststring3, 2) != 1)
	{
		printf("strnequ failed\n");
		result++;
	}
	bzero(teststring2, 26);
	if (ft_strnequ(teststring, teststring2, 25) != 0)
	{
		printf("strnequ failed\n");
		result++;
	}
	teststring = randomstring(len);
	teststring2 = teststring;
	if (strcmp(teststring2, ft_strsub(teststring, 0, strlen(teststring2))) != 0)
	{
		printf("strsub failed\n");
		result++;
	}

	teststring = randomstring(len);
	teststring2 = teststring;
	strcpy(teststring3, teststring);
	strcpy(teststring4, teststring2);
	char *strjoinstr;
	char *strjoinstr2;
	strjoinstr = ft_strjoin(teststring, teststring2);
	strjoinstr2 = ft_strncat(teststring3, teststring4, (strlen(teststring3) + strlen(teststring4) + 1));
	if (strcmp(strjoinstr, strjoinstr2) != 0)
	{
		printf("strjoin failed\n");
		result++;
	}

	char *strtrimstr;
	char *strtrimmedstr;
	strtrimstr = "   /t  H. e&7hkajsnn\t   .\n";
	strtrimmedstr = ft_strtrim(strtrimstr);
	if (!strcmp(strtrimmedstr, "/t  H. e&7hkajsnn\t   .\n"))
	{
		printf("strtrim failed\n");
		result++;
	}

	char *array1;
	char *array2;
	char *array3;
	char *array4;

	array1 = (char *)malloc(sizeof(char) * 11);
	array2 = (char *)malloc(sizeof(char) * 11);
	array3 = (char *)malloc(sizeof(char) * 11);
	array4 = (char *)malloc(sizeof(char) * 11);

	strcpy(array1, "7GJh2312##");
	strcpy(array1, "++");
	strcpy(array1, "~~~~~/");
	strcpy(array1, "Chocolate");

	if (!strcmp(ft_strsplit("---7GJh2312##-++-~~~~~/-Chocolate", '-')[0], array1))
	{
		printf("strsplit1 failed\n");
		result++;
	}
	if (!strcmp(ft_strsplit("---7GJh23120##-++-~~~~~/-Chocolate", '-')[1], array2))
	{
		printf("strsplit2 failed\n");
		result++;
	}
	if (!strcmp(ft_strsplit("---7GJh23120##-++-~~~~~/-Chocolate", '-')[2], array3))
	{
		printf("strsplit3 failed\n");
		result++;
	}
	if (!strcmp(ft_strsplit("---7GJh23120##-++-~~~~~/-Chocolate", '-')[3], array4))
	{
		printf("strsplit4 failed\n");
		result++;
	}

	free(array1);
	free(array2);
	free(array3);
	free(array4);

	char *newtester;
	char *comptester;

	newtester = (char *)malloc(sizeof(char) * 10 + 1);
	comptester = (char *)malloc(sizeof(char) * 10 + 1);
	newtester = ft_strmap("1234567890", &strmaptest);
	strcpy(comptester, "rrrrrhhhhr");
	if (strcmp(newtester, comptester) != 0)
	{
		printf("strmap failed\n");
		result++;
	}

	bzero(newtester, 11);
	bzero(comptester, 11);
	newtester = ft_strmapi("1234567890", &strmapitest);
	strcpy(comptester, "rrrrrhhhhr");
	if (strcmp(newtester, comptester) != 0)
	{
		printf("strmapi failed\n");
		result++;
	}
	free(newtester);
	free(comptester);

	char *itoastr1;
	char *itoastr2;
	char *itoastr3;

	itoastr1 = (char *)malloc(sizeof(char) * 12);
	itoastr2 = (char *)malloc(sizeof(char) * 6);
	itoastr3 = (char *)malloc(sizeof(char) * 7);

	strcpy(itoastr1, "-2147483648");
	strcpy(itoastr2, "-17001");
	strcpy(itoastr3, "7018340");

	if (strcmp(ft_itoa(-2147483648), itoastr1) != 0)
	{
		printf("itoa failed (test 1)\n");
		result++;
	}
	if (strcmp(ft_itoa(-17001), itoastr2) != 0)
	{
		printf("itoa failed (test 2)\n");
		result++;
	}
	if (strcmp(ft_itoa(7018340), itoastr3) != 0)
	{
		printf("itoa failed (test 3)\n");
		result++;
	}

	free(itoastr1);
	free(itoastr2);
	free(itoastr3);

	(void)argc;
	(void)argv;
	if (result == 0)
	{
		green();
		printf("\n\n[PASSED]\n\n\n");
		reset();
	}
	else
	{
		red();
		printf("\n\n[FAILED %d TESTS]\n\n\n", result);
	}
	return (0);
}


//tester for itoa and all onwards

//tester for list bonus functions
